const { MessageEmbed, Message } = require('discord.js');
const config = require('../config.json');

module.exports = {
	name: 'help', 
	description: 'Mostra lista de Comandos.',
    
	execute(message) {
		const { commands } = message.client;
        
        message.channel.send(
            new MessageEmbed()
            .setTitle(`${config.subtitulo} | Comando do gen`)
            .setDescription(`
**<:emoji_111:1180171825137860648> | help** - veja meus comandos
**<:emoji_111:1180171825137860648> | stock** - veja meus serviços
**<:emoji_111:1180171825137860648> | invite** - veja como me comprar
**<:emoji_111:1180171825137860648> | check** - cheque algum serviço`)
            .setThumbnail(config.thumbnail)
            .setColor(config.color)
        );
	}
};